<?php
include 'db.php';
session_start();

if (!isset($_SESSION['customer_id'])) {
    header("Location: login.php");
    exit;
}

$customer_id = $_SESSION['customer_id'];
$stmt = $conn->prepare("SELECT name, email, phone FROM customers WHERE id = ?");
$stmt->bind_param("i", $customer_id);
$stmt->execute();
$stmt->bind_result($name, $email, $phone);
$stmt->fetch();
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
    <h1>Customer Dashboard</h1>
    <p>Name: <?php echo $name; ?></p>
    <p>Email: <?php echo $email; ?></p>
    <p>Phone: <?php echo $phone; ?></p>
    
    <h2>Your Bookings</h2>
    <?php
    $result = $conn->query("SELECT bookings.id, cars.make, cars.model, bookings.start_date, bookings.end_date 
                            FROM bookings 
                            JOIN cars ON bookings.car_id = cars.id 
                            WHERE bookings.customer_id = $customer_id");

    while ($row = $result->fetch_assoc()):
    ?>
        <div class="booking">
            <p>Booking ID: <?php echo $row['id']; ?></p>
            <p>Car: <?php echo $row['make'] . " " . $row['model']; ?></p>
            <p>Start Date: <?php echo $row['start_date']; ?></p>
            <p>End Date: <?php echo $row['end_date']; ?></p>
        </div>
    <?php endwhile; ?>
</body>
</html>
