<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Car Rental</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
    <h1>Welcome to Car Rental</h1>

    <?php if (isset($_SESSION['customer_id'])): ?>
        <p>Welcome, Customer ID: <?php echo $_SESSION['customer_id']; ?>!</p>
        <a href="dashboard.php">Dashboard</a> |
        <a href="cars.php">View Cars</a> |
        <a href="book.php">Book a Car</a> |
        <a href="edit_profile.php">Edit Profile</a> |
        <a href="logout.php">Logout</a>
    <?php else: ?>
        <a href="register.php">Register</a> |
        <a href="login.php">Login</a> |
        <a href="cars.php">View Cars</a>
    <?php endif; ?>
</body>
</html>
