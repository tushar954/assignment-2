<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Car Rental</title>
    <style>
        .car {
            margin: 20px;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
        }
        .car img {
            max-width: 20%;
            height: auto;
            border-radius: 8px;
        }
        .car-details {
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <h1>Available Cars for Rent</h1>

    <div class="car">
        <img src="car1.jpg" alt="Car Model 1">
        <div class="car-details">
            <h2>Car Model 1</h2>
            <p>Make: Toyota</p>
            <p>Year: 2020</p>
            <p>Color: Red</p>
            <p>Price per day: $50</p>
        </div>
    </div>

    <div class="car">
        <img src="car2.jpg" alt="Car Model 2">
        <div class="car-details">
            <h2>Car Model 2</h2>
            <p>Make: Honda</p>
            <p>Year: 2019</p>
            <p>Color: Blue</p>
            <p>Price per day: $45</p>
        </div>
    </div>

    <!-- Add more cars similarly -->
</body>
</html>
